SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_FOLDER="$SCRIPT_DIR"
#Install Script For Pizza Tower - Pi Edition

#!/bin/bash

echo Installing Pizza Tower - Pi Edition...
echo This Project Would Have Not Been Possible
echo Without The Great People At Pi-Apps!
echo Support Botspot!

DIRECTORY="~/.martenapps/"

if [ -d "$DIRECTORY" ]; then
	echo "Packages Installed, Moving On."
else
	sudo apt remove box64 -y
	wget -qO- https://raw.githubusercontent.com/Botspot/pi-apps/master/install | bash
	~/pi-apps/manage install Box86
	~/pi-apps/manage install Box64
	~/pi-apps/manage install "Wine (x86)"
	~/pi-apps/manage install "Wine (x64)"

	sudo apt install xdelta3 -y
fi

echo "NOTE: You Will Need A Vaild Copy Of Pizza Tower For This Next Step. (V1.1.28)"

sudo rm -r ~/.martenapps/pizzatower-Reg/
sudo mkdir ~/.martenapps/
sudo mkdir ~/.martenapps/pizzatower-Reg/
sudo cp $DATA_FOLDER/.files/pizzatowericon.png ~/.martenapps/pizzatower-Reg/pizzatowericon.png
sudo xdelta3 -f -d -s $DATA_FOLDER/Game/data.win $DATA_FOLDER/Regular.xdelta ~/.martenapps/pizzatower-Reg/data.win
sudo cp -r $DATA_FOLDER/Game/ ~/.martenapps/pizzatower-Reg/
sudo cp $DATA_FOLDER/.files/runner.sh ~/.martenapps/pizzatower-Reg/Game/runner.sh
sudo rm ~/.martenapps/pizzatower-Reg/Game/data.win
sudo mv ~/.martenapps/pizzatower-Reg/data.win ~/.martenapps/pizzatower-Reg/Game/
sudo rm ~/.martenapps/pizzatower-Reg/Game/PUT\ STEAM\ GAME\ HERE.txt
sudo rm ~/.martenapps/pizzatower-Reg/Game/Steamworks_x64.dll
sudo cp $DATA_FOLDER/.files/runner.sh ~/Desktop/PizzaTower_Regular.sh

echo Finished! Go To The Desktop And Find "PizzaTower.sh"!