SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_FOLDER="$SCRIPT_DIR"

sudo rm -r ~/.martenapps/pizzatower-Reg/
sudo mkdir ~/.martenapps/pizzatower-Reg/
sudo cp $DATA_FOLDER/.files/pizzatowericon.png ~/.martenapps/pizzatower-Reg/pizzatowericon.png
sudo xdelta3 -d -s $DATA_FOLDER/Game/data.win $DATA_FOLDER/Regular.xdelta ~/.martenapps/pizzatower-Reg/data.win
sudo cp -r $DATA_FOLDER/Game/ ~/.martenapps/pizzatower-Reg/
sudo cp $DATA_FOLDER/.files/runner.sh ~/.martenapps/pizzatower-Reg/Game/runner.sh
sudo rm ~/.martenapps/pizzatower-Reg/Game/data.win
sudo mv ~/.martenapps/pizzatower-Reg/data.win ~/.martenapps/pizzatower-Reg/Game/
sudo rm ~/.martenapps/pizzatower-Reg/Game/PUT\ STEAM\ GAME\ HERE.txt
sudo rm ~/.martenapps/pizzatower-Reg/Game/Steamworks_x64.dll
sudo cp $DATA_FOLDER/.files/alacarte-made-999.desktop ~/.local/share/applications/alacarte-made-999.desktop

echo Finished! Go To The Start Menu And Go To "Other / Pizza Tower"!