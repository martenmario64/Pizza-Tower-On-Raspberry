#Install Script For Pizza Tower - Pi Edition

#!/bin/bash

echo This Project Would Have Not Been Possible
echo Without The Great People At Pi-Apps!
echo (Please Support Botspot!)

if dpkg -l box64 &>/dev/null ;then
  sudo apt purge -y --allow-change-held-packages box64*
fi

add_external_repo "box64" "https://pi-apps-coders.github.io/box64-debs/KEY.gpg" "https://Pi-Apps-Coders.github.io/box64-debs/debian" "./" || exit 1

apt_update
if [ $? != 0 ]; then
  rm_external_repo "box64"
  error "Failed to perform apt update after adding box64 repository."
fi

# obtain SOC_ID
get_model
if [[ "$SOC_ID" == "tegra-x1" ]] || [[ "$SOC_ID" == "tegra-x2" ]]; then
  install_packages box64-tegrax1 || exit 1
elif [[ "$SOC_ID" == "rk3399" ]]; then
  install_packages box64-rk3399 || exit 1
elif [[ "$SOC_ID" == "bcm2711" ]]; then
  install_packages box64-rpi4arm64 || exit 1
elif [[ "$SOC_ID" == "bcm2837" ]]; then
  install_packages box64-rpi3arm64 || exit 1
elif cat /proc/cpuinfo | grep -q aes; then
  warning "There is no box64 pre-build for your device $SOC_ID $model"
  warning "Installing the generic arm box64 build as a fallback (crypto extensions enabled)"
  install_packages box64-generic-arm || exit 1
else
  warning "There is no box64 pre-build for your device $SOC_ID $model"
  warning "Installing the RPI4 tuned box64 build as a fallback (no crypto extensions enabled)"
  install_packages box64-rpi4arm64 || exit 1
fi

#Wine Install 90
#!/bin/bash

#note to maintainer, if you change the below version make sure to update it in the uninstall script as well
version=11.4

# https://github.com/raspberrypi/bookworm-feedback/issues/107
PAGE_SIZE="$(getconf PAGE_SIZE)"
if [[ "$PAGE_SIZE" == "16384" ]]; then
  #switch to 4K pagesize kernel
  if [ -f /boot/config.txt ] || [ -f /boot/firmware/config.txt ]; then
    if [ -f /boot/firmware/config.txt ]; then
      boot_config="/boot/firmware/config.txt"
    elif [ -f /boot/config.txt ]; then
      boot_config="/boot/config.txt"
    fi
    text="Raspberry Pi 5 PiOS images ship by default with a 16K PageSize Linux Kernel.
This kernel causes incompatibilities with some software including Wine https://github.com/raspberrypi/bookworm-feedback/issues/107

Would you like to automatically switch to a 4K PageSize Linux Kernel?"
    userinput_func "$text" "No, keep 16K PageSize Kernel and Exit" "Yes, switch to 4K PageSize Kernel"
    if [ "$output" == "No, keep 16K PageSize Kernel and Exit" ]; then
      error "User error: Your current running kernel is built with 16K PageSize and is incompatible with Wine (x64) with Box64. You must switch to a 4K PageSize kernel (and chose to not do so automatically) before installing Wine (x64)."
    fi
    echo "" | sudo tee --append $boot_config >/dev/null
    echo "[pi5]" | sudo tee --append $boot_config >/dev/null
    echo "kernel=kernel8.img" | sudo tee --append $boot_config >/dev/null
    echo -e "The 4K PageSize Kernel has been enabled by adding 'kernel=kernel8.img' to $boot_config\nPlease reboot now and install the Wine (x64) app again."
    sleep infinity
  else
    error "User error (reporting allowed): Your current running kernel is built with 16K PageSize and is incompatible with Wine (x64) with Box64. Changing kernels automatically cannot be done since no /boot/config.txt or /boot/firmware/config.txt file was found."
  fi
fi

# Wine conflicts with Hangover
"${DIRECTORY}/manage" uninstall Hangover

# Get dependencies
install_packages cabextract p7zip-full || exit 1

#install box64
"${DIRECTORY}/manage" install-if-not-installed Box64 || error "Box64 failed to install somehow!"
if ! command -v box64 >/dev/null ;then
  error "User error: Pi-Apps thinks Box64 is installed, however no command named 'box64' exists. Please install Box64 manually."
fi
#upgrade box64
echo "Upgrading Box64 if necessary:"
apt_lock_wait
sudo apt install --only-upgrade box64-* -y
echo "Installed Box64 version:"
box64 -v || error "User error: Something went wrong when trying to run Box64."

# Remove old wine, while leaving config intact
pkill -9 wine
command -v wineserver >/dev/null && wineserver -k
command -v wine >/dev/null && sudo apt purge -y wine &>/dev/null &
sudo rm -rf /usr/local/bin/wine /usr/local/bin/wineboot /usr/local/bin/wineserver /usr/local/bin/winecfg /usr/local/bin/winetricks /opt/wine-${version} ~/.cache/winetricks ~/.cache/wine 2>/dev/null

less_tar() { #format tar verbose output to refresh same line with the next extracted file
  # Read from standard input line by line
  while IFS='' read -r line; do
    # Refresh the same line in the terminal with the latest extracted file
    echo -ne "$line"'\033[0K\r'
  done
  echo #add newline before exiting
}

# Download wine to /opt
wget https://github.com/Pi-Apps-Coders/files/releases/download/large-files/wine-${version}.tar.gz -O /tmp/wine-${version}.tar.gz || error 'Failed to download wine!'
status "Extracting: /tmp/wine-${version}.tar.gz"
sudo tar -xvf /tmp/wine-${version}.tar.gz -C /opt | less_tar
[ ${PIPESTATUS[0]} != 0 ] && error 'Failed to extract wine!'
rm -f /tmp/wine-${version}.tar.gz
status_green Done

#edit wine.inf to disable mime-associations. Nobody wants to double-click a text file, wonder why nothing is happening, then watch 15 Wine notepad windows pop up. Ask me how I know.
sudo sed -i 's/winemenubuilder.exe -a -r/winemenubuilder.exe -r/' /opt/wine-${version}/share/wine/wine.inf #See: https://askubuntu.com/a/400430

#download winetricks
wget -O /tmp/winetricks "https://raw.githubusercontent.com/Winetricks/winetricks/master/src/winetricks" || exit 1
sudo mv /tmp/winetricks /opt/wine-${version}/bin/winetricks || error "Failed to move winetricks script to /opt/wine-${version}/bin folder!"
sudo chmod +x /opt/wine-${version}/bin/winetricks

#download Mono to universal location (to be installed automatically in all wine prefixes)
#according to https://gitlab.winehq.org/wine/wine/-/wikis/Wine-Mono, use Mono 11.0.0 for Wine 11.4
#wine mono pacakge is called -x86 but contains both x86 and x86_64 binaries
sudo mkdir -p /opt/wine-${version}/share/wine/mono
wget -O "/tmp/wine-mono-11.0.0-x86.tar.xz" 'https://dl.winehq.org/wine/wine-mono/11.0.0/wine-mono-11.0.0-x86.tar.xz' || exit 1
status "Extracting: /tmp/wine-mono-11.0.0-x86.tar.xz"
sudo tar -xvf "/tmp/wine-mono-11.0.0-x86.tar.xz" -C "/opt/wine-${version}/share/wine/mono" | less_tar
[ ${PIPESTATUS[0]} != 0 ] && error 'Failed to extract wine-mono!'
rm -f "/tmp/wine-mono-11.0.0-x86.tar.xz"
status_green Done

#download Gecko to universal location (to be installed automatically in all wine prefixes)
#according to https://gitlab.winehq.org/wine/wine/-/wikis/Gecko, use Gecko 2.47.4 for Wine 8.6+
sudo mkdir -p /opt/wine-${version}/share/wine/gecko
wget -O "/tmp/wine-gecko-2.47.4-x86_64.tar.xz" 'https://dl.winehq.org/wine/wine-gecko/2.47.4/wine-gecko-2.47.4-x86_64.tar.xz' || exit 1
status "Extracting: /tmp/wine-gecko-2.47.4-x86_64.tar.xz"
sudo tar -xvf "/tmp/wine-gecko-2.47.4-x86_64.tar.xz" -C "/opt/wine-${version}/share/wine/gecko" | less_tar
[ ${PIPESTATUS[0]} != 0 ] && error 'Failed to extract wine-gecko!'
rm -f "/tmp/wine-gecko-2.47.4-x86_64.tar.xz"
status_green Done

status "Creating terminal commands:"
echo "  - winecfg"
sudo ln -s /opt/wine-${version}/bin/winecfg /usr/local/bin/winecfg
echo "  - wineserver"
sudo ln -s /opt/wine-${version}/bin/wineserver /usr/local/bin/wineserver
echo "  - wineboot"
sudo ln -s /opt/wine-${version}/bin/wineboot /usr/local/bin/wineboot
echo "  - wine"
sudo ln -s /opt/wine-${version}/bin/wine /usr/local/bin/wine

echo "  - winetricks"
echo "#!/bin/bash
BOX64_NOBANNER=1 /opt/wine-${version}/bin/winetricks"' "$@"' | sudo tee /usr/local/bin/winetricks >/dev/null

#make them all executable
status -n "Making executable... "
sudo chmod +x /usr/local/bin/winecfg /usr/local/bin/wineserver /usr/local/bin/wineboot /usr/local/bin/wine /usr/local/bin/winetricks || error "\nFailed to mark all commands as executable. Most likely one failed to be generated or copied. These files are:\n/usr/local/bin/winecfg\n/usr/local/bin/wineserver\n/usr/local/bin/wineboot\n/usr/local/bin/wine\n/usr/local/bin/winetricks"
status_green "Done"

#get icons from wine-stuff repo
cd /tmp
rm -rf wine-stuff
git clone https://github.com/Botspot/wine-stuff || error "Failed to clone wine-stuff repository!"
sudo mv wine-stuff/icons /opt/wine-${version}
sudo mv wine-stuff/Windows_10.msstyles /opt/wine-${version}
sudo chown -R root:root /opt/wine-${version}
rm -rf wine-stuff
cd

#create menu launchers
status -n "Creating Menu launchers... "

#Remove wine auto-generated desktop files that handle mimetypes. Nobody in their right mind would want this.
#See: https://askubuntu.com/a/400430
rm -f ~/.local/share/mime/packages/x-wine*
rm -f ~/.local/share/applications/wine-extension*
rm -f ~/.local/share/icons/hicolor/*/*/application-x-wine-extension*
rm -f ~/.local/share/mime/application/x-wine-extension*

echo "[Desktop Entry]
StartupNotify=true
Terminal=false
Type=Application
Name=Wine Configuration
Exec=wine winecfg
Icon=/opt/wine-${version}/icons/winecfg.png
Categories=System;
Comment=Configure wine" | sudo tee /usr/share/applications/wine-config.desktop >/dev/null

echo "[Desktop Entry]
Name=Winetricks
Comment=Work around problems and install applications under Wine
Exec=bash -c 'BOX64_NOBANNER=1 box64 winetricks --gui'
Terminal=false
Icon=/opt/wine-${version}/icons/winetricks.png
Type=Application
Categories=System;" | sudo tee /usr/share/applications/wine-tricks.desktop >/dev/null

echo "[Desktop Entry]
Version=1.0
Type=Application
Name=Wine Desktop
Comment=Wine graphical desktop environment to mimic a Windows OS
Icon=/opt/wine-${version}/icons/wine-desktop.png
Exec=wine explorer /desktop=shell,1280x720
Terminal=false
Categories=System;" | sudo tee /usr/share/applications/wine-explorer.desktop >/dev/null

echo "[Desktop Entry]
Version=1.0
Type=Application
Name=Wine Program Manager
Comment=Install/Remove Windows programs
Icon=/opt/wine-${version}/icons/wine-program-manager.png
Exec=wine uninstaller
Terminal=false
Categories=System;" | sudo tee /usr/share/applications/wine-uninstaller.desktop >/dev/null

echo "[Desktop Entry]
Version=1.0
Type=Application
Name=Wine Task Manager
Comment=View running processes within Wine
Icon=/opt/wine-${version}/icons/winetask.png
Exec=wine taskmgr
Terminal=false
Categories=System;" | sudo tee /usr/share/applications/wine-taskmgr.desktop >/dev/null

echo "[Desktop Entry]
StartupNotify=false
Version=1.0
Type=Application
Name=Wine Killer
Comment=Terminate any running Wine processes
Icon=/opt/wine-${version}/icons/winestop.png
Exec=wineserver -k
Terminal=false
Categories=System;" | sudo tee /usr/share/applications/wine-killer.desktop >/dev/null

echo "[Desktop Entry]
Version=1.0
Type=Application
Name=Wine Reset
Comment=Clean out the default Wine prefix and start over
Icon=/opt/wine-${version}/icons/wine-regenerate.png
Exec=bash -c "\""yad --window-icon=/opt/wine-${version}/icons/wine-regenerate.png --title='Wine Reset' --text='Are you sure you want to DELETE all data and applications in your Wine prefix and start over?' --center --button=Cancel:1 --button=Yes:0 --on-top && ${DIRECTORY}/etc/terminal-run 'echo y | winetricks annihilate -q ; generate-wine-prefix' 'Generating Wine prefix...'"\""
Terminal=false
Categories=System;" | sudo tee /usr/share/applications/wine-regenerate.desktop >/dev/null
status_green "Done"

cat << EOF | sudo tee /usr/local/bin/generate-wine-prefix >/dev/null
#!/bin/bash
echo

#set up functions
$(declare -f error)
$(declare -f status)
$(declare -f status_green)
$(declare -f warning)
$(declare -f userinput_func)

if [ "\$(id -u)" == 0 ];then
  error "Please don't run this script with sudo."
fi

if [ -z "\$WINEPREFIX" ];then
  WINEPREFIX="\$HOME/.wine"
fi
export WINEPREFIX
export BOX64_NOBANNER=1 #hide box64 output (for cosmetics)

if [ -f "\$WINEPREFIX/system.reg" ];then
  registry_exists=true
else
  registry_exists=false
fi

export WINEDEBUG=-virtual #hide harmless memory errors

if [ -e "\$WINEPREFIX" ];then
  status "Checking Wine prefix at \$WINEPREFIX..."
  echo "To choose another prefix, set the WINEPREFIX variable."
  echo -n "Waiting 5 seconds... "
  sleep 5
  echo
  # check for existance of incompatible prefix (see server_init_process https://github.com/wine-mirror/wine/blob/884cff821481b4819f9bdba455217bd5a3f97744/dlls/ntdll/unix/server.c#L1544-L1670)
  # Boot wine and check for errors (make fresh wineprefix)
  output="\$(set -o pipefail; wine wineboot 2>&1 | tee /dev/stderr; )" #this won't display any dialog boxes that require a button to be clicked
  if [ "\$?" != 0 ]; then
    text="Your previously existing Wine prefix failed with an error (see terminal log).

Would you like to remove and regenerate your Wine prefix? Doing so will delete anything you may have installed into your Wine prefix."
    userinput_func "\$text" "No, keep broken Wine prefix and Exit" "Yes, delete and regenerate Wine prefix"
    if [ "\$output" == "No, keep broken Wine prefix and Exit" ]; then
      error "User error: Your current Wine prefix caused Wine to error on launch and you chose to keep it. Manually correct your Wine prefix before installing or updating Wine (x64)."
    fi
    warning "Your previously existing Wine prefix failed with an error (see above). You chose to remove it and so it will be re-generated."
    rm -rf "\$WINEPREFIX"
    registry_exists=false
    wine wineboot #this won't display any dialog boxes that require a button to be clicked
  fi
  #wait until above process exits
  sleep 2
  while [ ! -z "\$(pgrep -i 'wine C:')" ];do
    sleep 1
  done
else
  status "Generating Wine prefix at \$WINEPREFIX..."
  echo "To choose another prefix, set the WINEPREFIX variable."
  echo "Waiting 5 seconds..."
  sleep 5
  # Boot wine (make fresh wineprefix)
  wine wineboot #this won't display any dialog boxes that require a button to be clicked
  #wait until above process exits
  sleep 2
  while [ ! -z "\$(pgrep -i 'wine C:')" ];do
    sleep 1
  done
fi

if [ "\$registry_exists" == false ];then
status "Making registry changes..."
TMPFILE="\$(mktemp)" || exit 1
echo 'REGEDIT4' > \$TMPFILE

#enable font smoothing - see https://askubuntu.com/a/219795
echo "  - Font smoothing"

MODE=2 # 0 = disabled; 2 = enabled
TYPE=2 # 1 = regular;  2 = subpixel
ORIENTATION=1 # 0 = BGR; 1 = RGB

echo '
[HKEY_CURRENT_USER\Control Panel\Desktop]
"FontSmoothing"="'\$MODE'"
"FontSmoothingOrientation"=dword:0000000'\$ORIENTATION'
"FontSmoothingType"=dword:0000000'\$TYPE'
"FontSmoothingGamma"=dword:00000578' >> \$TMPFILE

echo "  - Windows 10 appearance theme"
mkdir -p "\$WINEPREFIX/drive_c/windows/Resources/Themes/Windows_10"
cp -f /opt/wine-${version}/Windows_10.msstyles "\$WINEPREFIX/drive_c/windows/Resources/Themes/Windows_10"

echo '
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\ThemeManager]
"ColorName"="NormalColor"
"DllName"="C:\\\\windows\\\\Resources\\\\Themes\\\\Windows_10\\\\Windows_10.msstyles"
"FlatMenu"=dword:00000000
"GradientCaption"=dword:00000001
"IconTitleFont"=hex:f5,ff,ff,ff,00,00,00,00,00,00,00,00,00,00,00,00,90,01,00,\
  00,00,00,00,00,00,00,00,22,54,00,61,00,68,00,6f,00,6d,00,61,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00
"NonClientMetrics"=hex:f8,01,00,00,01,00,00,00,10,00,00,00,10,00,00,00,12,00,\
  00,00,12,00,00,00,f5,ff,ff,ff,00,00,00,00,00,00,00,00,00,00,00,00,bc,02,00,\
  00,00,00,00,00,00,00,00,22,54,00,61,00,68,00,6f,00,6d,00,61,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,0f,00,\
  00,00,0f,00,00,00,fa,ff,ff,ff,00,00,00,00,00,00,00,00,00,00,00,00,90,01,00,\
  00,00,00,00,00,00,00,00,22,54,00,61,00,68,00,6f,00,6d,00,61,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,12,00,\
  00,00,12,00,00,00,f5,ff,ff,ff,00,00,00,00,00,00,00,00,00,00,00,00,90,01,00,\
  00,00,00,00,00,00,00,00,22,54,00,61,00,68,00,6f,00,6d,00,61,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,f5,ff,\
  ff,ff,00,00,00,00,00,00,00,00,00,00,00,00,90,01,00,00,00,00,00,00,00,00,00,\
  22,54,00,61,00,68,00,6f,00,6d,00,61,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,f5,ff,ff,ff,00,00,00,00,00,00,\
  00,00,00,00,00,00,90,01,00,00,00,00,00,00,00,00,00,22,54,00,61,00,68,00,6f,\
  00,6d,00,61,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00
"SizeName"="NormalSize"
"ThemeActive"="1"

[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\ThemeManager\Control Panel\Colors]
"ActiveBorder"="212 208 200"
"ActiveTitle"="10 36 106"
"AppWorkSpace"="128 128 128"
"Background"="58 110 165"
"ButtonAlternateFace"="181 181 181"
"ButtonDkShadow"="64 64 64"
"ButtonFace"="212 208 200"
"ButtonHilight"="255 255 255"
"ButtonLight"="212 208 200"
"ButtonShadow"="128 128 128"
"ButtonText"="0 0 0"
"GradientActiveTitle"="166 202 240"
"GradientInactiveTitle"="192 192 192"
"GrayText"="128 128 128"
"Hilight"="10 36 106"
"HilightText"="255 255 255"
"HotTrackingColor"="0 0 200"
"InactiveBorder"="212 208 200"
"InactiveTitle"="128 128 128"
"InactiveTitleText"="212 208 200"
"InfoText"="0 0 0"
"InfoWindow"="255 255 225"
"Menu"="212 208 200"
"MenuBar"="212 208 200"
"MenuHilight"="10 36 106"
"MenuText"="0 0 0"
"Scrollbar"="212 208 200"
"TitleText"="255 255 255"
"Window"="255 255 255"
"WindowFrame"="0 0 0"
"WindowText"="0 0 0"

[HKEY_CURRENT_USER\Control Panel\Colors]
"ActiveBorder"="212 208 200"
"ActiveTitle"="115 188 238"
"AppWorkSpace"="128 128 128"
"Background"="0 0 0"
"ButtonAlternateFace"="181 181 181"
"ButtonDkShadow"="106 106 106"
"ButtonFace"="240 240 240"
"ButtonHilight"="255 255 255"
"ButtonLight"="227 227 227"
"ButtonShadow"="165 165 165"
"ButtonText"="0 0 0"
"GradientActiveTitle"="115 188 238"
"GradientInactiveTitle"="158 214 250"
"GrayText"="165 165 165"
"Hilight"="231 239 245"
"HilightText"="0 0 0"
"HotTrackingColor"="59 152 211"
"InactiveBorder"="212 208 200"
"InactiveTitle"="158 214 250"
"InactiveTitleText"="150 150 150"
"InfoText"="0 0 0"
"InfoWindow"="255 255 225"
"Menu"="255 255 255"
"MenuBar"="240 240 240"
"MenuHilight"="230 230 230"
"MenuText"="0 0 0"
"Scrollbar"="212 208 200"
"TitleText"="28 28 28"
"Window"="255 255 255"
"WindowFrame"="0 0 0"
"WindowText"="0 0 0"

[HKEY_CURRENT_USER\Control Panel\Desktop\WindowMetrics]
"BorderWidth"="1"
"CaptionFont"=hex:08,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,bc,02,00,00,\
  00,00,00,00,00,00,00,22,54,00,61,00,68,00,6f,00,6d,00,61,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00
"IconFont"=hex:09,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,90,01,00,00,00,\
  00,00,01,00,00,00,00,53,00,65,00,67,00,6f,00,65,00,20,00,55,00,49,00,20,00,\
  53,00,65,00,6d,00,69,00,62,00,6f,00,6c,00,64,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00
"MenuFont"=hex:08,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,90,01,00,00,00,\
  00,00,00,00,00,00,22,54,00,61,00,68,00,6f,00,6d,00,61,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00
"MessageFont"=hex:08,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,90,01,00,00,\
  00,00,00,00,00,00,00,22,54,00,61,00,68,00,6f,00,6d,00,61,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00
"ScrollHeight"="-255"
"ScrollWidth"="-255"
"SmCaptionFont"=hex:05,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,90,01,00,\
  00,00,00,00,01,00,00,00,00,53,00,65,00,67,00,6f,00,65,00,20,00,55,00,49,00,\
  20,00,53,00,65,00,6d,00,69,00,62,00,6f,00,6c,00,64,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00
"SmCaptionHeight"="-300"
"SmCaptionWidth"="-300"
"StatusFont"=hex:08,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,90,01,00,00,\
  00,00,00,00,00,00,00,22,54,00,61,00,68,00,6f,00,6d,00,61,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,\
  00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00' >> \$TMPFILE

echo "  - Setting DPI to 120"
echo '
[HKEY_LOCAL_MACHINE\System\CurrentControlSet\Hardware Profiles\Current\Software\Fonts]
"LogPixels"=dword:00000078

[HKEY_CURRENT_USER\Software\Wine\Fonts]
"LogPixels"=dword:00000078

[HKEY_CURRENT_USER\Control Panel\Desktop]
"LogPixels"=dword:00000078' >> \$TMPFILE

echo "  - Disabling Wine mime associations" #see https://askubuntu.com/a/400430

echo '
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\RunServices]
"winemenubuilder"="C:\\\\windows\\\\system32\\\\winemenubuilder.exe -r"

[HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\RunServices]
"winemenubuilder"="C:\\\\windows\\\\system32\\\\winemenubuilder.exe -r"' >> \$TMPFILE

wine regedit \$TMPFILE

rm -f \$TMPFILE
fi #end of if statement that only runs if this script was started when there was no wine registry

#install some packages with winetricks for a better out-of-the-box experience
export W_OPT_UNATTENDED=1 #Avoid opening any dialog windows; install everything in unattended mode

installed="\$(WINETRICKS_SUPER_QUIET=1 winetricks -q list-installed 2>/dev/null)"
for i in mfc42 vcrun6 vcrun2003 fontfix corefonts gdiplus msxml3 vcrun2005sp1 vcrun2008 ;do
  echo
  status -n "Installing \$i with winetricks..."
  if echo "\$installed" | grep -qFx "\$i" ;then
    status_green " Already installed"
  else
    echo
    winetricks \$i
  fi
done
status "Winetricks finished"

#update the wine prefix (~/.wine) to fix the issue that causes wine to not know its system drive
wine wineboot -u
#wait until above process exits
sleep 2
while [ ! -z "\$(pgrep -i 'wine C:')" ];do
  sleep 1
done
true
EOF

sudo chmod +x /usr/local/bin/generate-wine-prefix
/usr/local/bin/generate-wine-prefix

sudo apt install xdelta3 -y

echo NOTE: You Will Need A Vaild Copy Of Pizza Tower For This Next Step. (V1.1.28)
./patcher.sh